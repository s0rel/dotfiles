// ==UserScript==
// @name 秒传链接提取
// @version 2.2.3
// @author mengzonefire
// @description 用于提取和生成百度网盘秒传链接
// @homepage https://greasyfork.org/zh-CN/scripts/424574
// @supportURL https://github.com/mengzonefire/rapid-upload-userscript/issues
// @match *://pan.baidu.com/disk/home*
// @match *://pan.baidu.com/disk/main*
// @match *://yun.baidu.com/disk/home*
// @match *://yun.baidu.com/disk/main*
// @match *://wangpan.baidu.com/disk/home*
// @match *://wangpan.baidu.com/disk/main*
// @name:en rapidupload-userscript
// @license GPLv3
// @icon data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABBUlEQVR4AZTTJRBUURTH4TtDwXuPdPrgbhHXiksf3CPucRNScHd3d3d3uO9bKeu7b79+fun8Q17CNHyMMUqaiPE4fEyYVjjGNKnNwQ4lpgV8lManEfwfosLHEGPU1N3ZnAv4qlT+NiQ56uPWSjKBrztUSnIaB66sY1vgxgxoMXB5NbsCB9rxcB5fN2M5/16nCFxeS6YTezpzsB1Pu/C2O7/78/99eYBYHXh+gqdHObGIK4GHgevjVIt1AgAnhvE4cGe8euoHbizgYuD2RGgx8O0RpwIPRmsmJDGqcrANd3pLo/qVr03hUlcpfSwf0/vD3JwkPdPK5/zhkOz+/f1FIDv/RcnOAEjywH/DhgADAAAAAElFTkSuQmCC
// @namespace moe.cangku.mengzonefire
// @homepageURL https://greasyfork.org/zh-CN/scripts/424574
// @contributionURL https://afdian.net/@mengzonefire
// @description:en input bdlink to get files or get bdlink for Baidu™ WebDisk.
// @compatible firefox Violentmonkey
// @compatible firefox Tampermonkey
// @compatible chrome Violentmonkey
// @compatible chrome Tampermonkey
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_deleteValue
// @grant GM_setClipboard
// @grant GM_getResourceText
// @grant GM_addStyle
// @grant GM_xmlhttpRequest
// @grant unsafeWindow
// @resource swalCss https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css
// @resource swalCssBak https://unpkg.com/sweetalert2@11/dist/sweetalert2.min.css
// @require https://cdn.staticfile.org/jquery/3.6.0/jquery.min.js
// @require https://cdn.staticfile.org/spark-md5/3.0.0/spark-md5.min.js
// @require https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js
// @require https://cdn.jsdelivr.net/npm/js-base64@3.7.2/base64.min.js
// @require https://unpkg.com/sweetalert2@11/dist/sweetalert2.min.js
// @require https://unpkg.com/js-base64@3.7.2/base64.js
// @run-at document-start
// @connect baidu.com
// @connect baidupcs.com
// @connect cdn.jsdelivr.net
// @connect *
// ==/UserScript==

/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 119:
/***/ ((module) => {

module.exports = ".mzf_btn{text-align:center;font-size:.85em;color:#09aaff;border:2px solid #c3eaff;border-radius:4px;margin:0 5px;padding:10px;padding-top:5px;padding-bottom:5px;cursor:pointer}.mzf_link{font-family:inherit;color:#09aaff;text-decoration:none;vertical-align:baseline}.mzf_text{font-feature-settings:\"lnum\";-webkit-font-smoothing:antialiased;font-family:inherit;color:#545454;font-weight:400;word-break:break-word;-webkit-tap-highlight-color:transparent;margin:0;padding:0;width:100%;height:34px;display:block;line-height:34px;text-align:center}.mzf_new_btn{-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:transparent;vertical-align:middle;font:inherit;overflow:visible;text-transform:none;font-family:SFUIText,PingFangSC-Regular,Helvetica Neue,Helvetica,Arial,sans-serif;display:inline-block;line-height:1;white-space:nowrap;cursor:pointer;background:#fff;text-align:center;box-sizing:border-box;outline:0;margin:0;transition:.1s;color:#fff;background-color:#06a7ff;font-weight:700;padding:8px 24px;height:32px;font-size:14px;border-radius:16px;border:none}svg{margin-right:5px;transform:rotate(180deg);transition:transform .2s;fill:none;stroke:gray}.mzf_details{cursor:pointer}.mzf_content{max-height:0;margin:0;transition:max-height .5s;overflow:hidden}.mzf_details[open]>summary>svg{transform:rotate(0deg)}.mzf_details[open]+.mzf_content{max-height:100%}.mzf_html_container{grid-template-columns:minmax(0, 100%);align-self:center;justify-self:center;width:32em;max-width:100%}.mzf_updateInfo{border:1px #000;width:100%;margin:0 auto}.mzf_updateInfo span{vertical-align:baseline}"

/***/ }),

/***/ 197:
/***/ ((module) => {

module.exports = "input[type=\"checkbox\"],\r\ninput[type=\"radio\"] {\r\n  --active: #275efe;\r\n  --active-inner: #fff;\r\n  --focus: 2px rgba(39, 94, 254, 0.3);\r\n  --border: #bbc1e1;\r\n  --border-hover: #275efe;\r\n  --background: #fff;\r\n  --disabled: #f6f8ff;\r\n  --disabled-inner: #e1e6f9;\r\n  -webkit-appearance: none;\r\n  -moz-appearance: none;\r\n  height: 21px;\r\n  outline: none;\r\n  display: inline-block;\r\n  vertical-align: top;\r\n  position: relative;\r\n  margin: 0;\r\n  cursor: pointer;\r\n  border: 1px solid var(--bc, var(--border));\r\n  background: var(--b, var(--background));\r\n  -webkit-transition: background 0.3s, border-color 0.3s, box-shadow 0.2s;\r\n  transition: background 0.3s, border-color 0.3s, box-shadow 0.2s;\r\n}\r\ninput[type=\"checkbox\"]:after,\r\ninput[type=\"radio\"]:after {\r\n  content: \"\";\r\n  display: block;\r\n  left: 0;\r\n  top: 0;\r\n  position: absolute;\r\n  -webkit-transition: opacity var(--d-o, 0.2s),\r\n    -webkit-transform var(--d-t, 0.3s) var(--d-t-e, ease);\r\n  transition: opacity var(--d-o, 0.2s),\r\n    -webkit-transform var(--d-t, 0.3s) var(--d-t-e, ease);\r\n  transition: transform var(--d-t, 0.3s) var(--d-t-e, ease),\r\n    opacity var(--d-o, 0.2s);\r\n  transition: transform var(--d-t, 0.3s) var(--d-t-e, ease),\r\n    opacity var(--d-o, 0.2s),\r\n    -webkit-transform var(--d-t, 0.3s) var(--d-t-e, ease);\r\n}\r\ninput[type=\"checkbox\"]:checked,\r\ninput[type=\"radio\"]:checked {\r\n  --b: var(--active);\r\n  --bc: var(--active);\r\n  --d-o: 0.3s;\r\n  --d-t: 0.6s;\r\n  --d-t-e: cubic-bezier(0.2, 0.85, 0.32, 1.2);\r\n}\r\ninput[type=\"checkbox\"]:disabled,\r\ninput[type=\"radio\"]:disabled {\r\n  --b: var(--disabled);\r\n  cursor: not-allowed;\r\n  opacity: 0.9;\r\n}\r\ninput[type=\"checkbox\"]:disabled:checked,\r\ninput[type=\"radio\"]:disabled:checked {\r\n  --b: var(--disabled-inner);\r\n  --bc: var(--border);\r\n}\r\ninput[type=\"checkbox\"]:disabled + label,\r\ninput[type=\"radio\"]:disabled + label {\r\n  cursor: not-allowed;\r\n}\r\ninput[type=\"checkbox\"]:hover:not(:checked):not(:disabled),\r\ninput[type=\"radio\"]:hover:not(:checked):not(:disabled) {\r\n  --bc: var(--border-hover);\r\n}\r\ninput[type=\"checkbox\"]:focus,\r\ninput[type=\"radio\"]:focus {\r\n  box-shadow: 0 0 0 var(--focus);\r\n}\r\ninput[type=\"checkbox\"]:not(.switch),\r\ninput[type=\"radio\"]:not(.switch) {\r\n  width: 21px;\r\n}\r\ninput[type=\"checkbox\"]:not(.switch):after,\r\ninput[type=\"radio\"]:not(.switch):after {\r\n  opacity: var(--o, 0);\r\n}\r\ninput[type=\"checkbox\"]:not(.switch):checked,\r\ninput[type=\"radio\"]:not(.switch):checked {\r\n  --o: 1;\r\n}\r\ninput[type=\"checkbox\"] + label,\r\ninput[type=\"radio\"] + label {\r\n  font-size: 18px;\r\n  line-height: 21px;\r\n  display: inline-block;\r\n  vertical-align: top;\r\n  cursor: pointer;\r\n  margin-left: 4px;\r\n}\r\n\r\ninput[type=\"checkbox\"]:not(.switch) {\r\n  border-radius: 7px;\r\n}\r\ninput[type=\"checkbox\"]:not(.switch):after {\r\n  width: 5px;\r\n  height: 9px;\r\n  border: 2px solid var(--active-inner);\r\n  border-top: 0;\r\n  border-left: 0;\r\n  left: 7px;\r\n  top: 4px;\r\n  -webkit-transform: rotate(var(--r, 20deg));\r\n  transform: rotate(var(--r, 20deg));\r\n}\r\ninput[type=\"checkbox\"]:not(.switch):checked {\r\n  --r: 43deg;\r\n}\r\ninput[type=\"checkbox\"].switch {\r\n  width: 38px;\r\n  border-radius: 11px;\r\n}\r\ninput[type=\"checkbox\"].switch:after {\r\n  left: 2px;\r\n  top: 2px;\r\n  border-radius: 50%;\r\n  width: 15px;\r\n  height: 15px;\r\n  background: var(--ab, var(--border));\r\n  -webkit-transform: translateX(var(--x, 0));\r\n  transform: translateX(var(--x, 0));\r\n}\r\ninput[type=\"checkbox\"].switch:checked {\r\n  --ab: var(--active-inner);\r\n  --x: 17px;\r\n}\r\ninput[type=\"checkbox\"].switch:disabled:not(:checked):after {\r\n  opacity: 0.6;\r\n}\r\n"

/***/ }),

/***/ 184:
/***/ ((module) => {

module.exports = "<div class=\"panel-body\" style=\"height: 250px; overflow-y: scroll\">\r\n  <div class=\"mzf_updateInfo\">\r\n    <span>\r\n      <p>\r\n        若喜欢该脚本可前往\r\n        <a href=\"https://afdian.net/@mengzonefire\" class=\"mzf_link\" rel=\"noopener noreferrer\" target=\"_blank\">赞助页</a>\r\n        支持作者\r\n      </p>\r\n\r\n      <p>\r\n        若出现任何问题请前往\r\n        <a href=\"https://greasyfork.org/zh-CN/scripts/424574\" class=\"mzf_link\" rel=\"noopener noreferrer\"\r\n          target=\"_blank\">脚本主页</a>\r\n        反馈\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.2.0 更新内容(22.3.24):</p>\r\n\r\n      <p>1.修复重复弹窗时出现的背景闪屏问题</p>\r\n\r\n      <p>2.将输入秒传和保存路径的窗口整合, 减少弹窗步骤</p>\r\n\r\n      <p>3.设置页新增 \"<span style=\"color: red\">监听剪贴板</span>\" 功能, 开启后可自动粘贴秒传</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.1.5 更新内容(22.3.17):</p>\r\n\r\n      <p>转存完成后同时显示成功和失败列表折叠框</p>\r\n\r\n      <img src=\"https://pic3.58cdn.com.cn/nowater/webim/big/n_v2227bef15f950440bae9e4b710fb42eb5.gif\" />\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.1.3 更新内容(22.2.24):</p>\r\n\r\n      <p>1. 修复新版度盘页面下的按钮样式</p>\r\n\r\n      <p>2. 修复新版度盘页面下的 \"打开目录\" 功能</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.1.0 更新内容(22.1.22):</p>\r\n\r\n      <p>支持 新版度盘页面 下的 \"生成秒传\" 功能</p>\r\n\r\n      <img src=\"https://pic.rmb.bdstatic.com/bjh/8c05bf7c7ba44cb6f7e0a68c3e17ab54.png\" />\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.0.20 更新内容(22.1.22):</p>\r\n\r\n      <p>\r\n        修复部分生成秒传时提示 \"请求失败...(#514)\" 的问题, 生成时若弹出跨域提示,\r\n        请选择允许\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.0.12 更新内容(21.11.9):</p>\r\n\r\n      <p>\r\n        修复所有失效的文档链接, 见\r\n        <a href=\"https://mengzonefire.code.misakanet.cn/rapid-upload-userscript-doc\" class=\"mzf_link\"\r\n          rel=\"noopener noreferrer\" target=\"_blank\">文档目录</a>\r\n      </p>\r\n\r\n      <p>修复在目标目录下点击\"打开目录\"按钮, 文件列表不刷新的问题</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.0.11 更新内容(21.10.18):</p>\r\n\r\n      <p>移除一处可能导致生成错误秒传的代码</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.0.10 更新内容(21.10.1):</p>\r\n\r\n      <p>修复失效的教程文档地址</p>\r\n\r\n      <p>*部分地区打开显示石墨文档正在升级</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>2.0.5 更新内容(21.9.1):</p>\r\n\r\n      <p>\r\n        转存路径留空现改为默认转存到 <span style=\"color: red\">当前目录</span>\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p><span style=\"color: red\">2.0.0</span> 更新内容(21.8.30):</p>\r\n\r\n      <p>1.移除游侠秒传格式的支持</p>\r\n\r\n      <p>2.重构代码, 全面优化, 提升使用体验</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.8.5 更新内容(21.7.30):</p>\r\n\r\n      <p>\r\n        修复了部分转存提示 \"<span style=\"color: red\">转存失败(尝试...)(#2)</span>\" 的问题\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.8.4 更新内容(21.7.18):</p>\r\n\r\n      <p>\r\n        修复了部分生成提示 \"<span style=\"color: red\">md5获取失败</span>\" 的问题\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.8.1 更新内容(21.7.6):</p>\r\n\r\n      <p>支持转存与生成 <span style=\"color: red\">20G以上</span> 文件的秒传</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.7.9 更新内容(21.6.28):</p>\r\n\r\n      <p>1.大幅提升非会员账号生成秒传的速度</p>\r\n\r\n      <p>\r\n        2.修复生成4G以上文件提示\"<span style=\"color: red\">服务器错误(#500)</span>\"的问题\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.7.8 更新内容(21.6.25):</p>\r\n\r\n      <p>\r\n        修复了绝大部分转存提示 \"<span style=\"color: red\">文件不存在(秒传未生效)(#404)</span>\" 的问题\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.7.3 更新内容(21.6.23):</p>\r\n\r\n      <p>升级样式&主题, 提升观感, 修复了设置内的主题适配</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.6.8 更新内容(21.6.18)</p>\r\n\r\n      <p>\r\n        移除 <span style=\"color: red\">修复下载</span> 功能(已在21年4月上旬失效),\r\n        后续不会再考虑修复该功能\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.6.7 更新内容(21.3.30)</p>\r\n\r\n      <p>修复部分秒传转存时提示 \"文件不存在(秒传无效)\"</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.6.1 更新内容(21.3.29)</p>\r\n\r\n      <p>\r\n        新增 <span style=\"color: red\">直接修复下载</span> 的功能,\r\n        选中网盘内文件, 再点击上方\r\n        <span style=\"color: red\">修复下载</span> 按钮即可生成可正常下载的新文件\r\n      </p>\r\n\r\n      <img src=\"https://pic.rmb.bdstatic.com/bjh/5e05f7c1f772451b8efce938280bcaee.png\" />\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.5.7 更新内容(21.3.9)</p>\r\n\r\n      <p>\r\n        修复部分文件转存后 <span style=\"color: red\">无法下载</span> 的问题,\r\n        可尝试 <span style=\"color: red\">重新转存</span> 之前无法下载文件.\r\n        且转存新增了 <span style=\"color: red\">修复下载</span> 功能\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.5.4 更新内容(21.2.11)</p>\r\n\r\n      <p>\r\n        面向分享者的\r\n        <a href=\"https://mengzonefire.code.misakanet.cn/rapid-upload-userscript-doc/generate-bdcode/\"\r\n          rel=\"noopener noreferrer\" target=\"_blank\">分享教程</a>\r\n        的防和谐方法更新:\r\n      </p>\r\n\r\n      <p>\r\n        经测试, 原教程的 \"固实压缩+加密文件名\"\r\n        已无法再防和谐(在度盘移动端依旧可以在线解压),\r\n        目前有效的防和谐方法请参考教程内的\r\n        <span style=\"color: red\">\"双层压缩\"</span>\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.4.3 更新内容(21.2.6):</p>\r\n\r\n      <p>修复了生成秒传时, 秒传有效, 仍提示\"md5获取失败(#996)\"的问题</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.4.9 更新内容(21.1.28):</p>\r\n\r\n      <p>1. 重新兼容了暴力猴插件, 感谢Trendymen提供的代码</p>\r\n\r\n      <p>\r\n        2. 新增更换主题的功能, 在秒传输入框中输入setting进入设置页,\r\n        更换为其他主题, 即可避免弹窗时的背景变暗\r\n      </p>\r\n\r\n      <p>3. 修改了部分代码逻辑, 秒传按钮不会再出现在最左边了</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.4.6 更新内容(21.1.14):</p>\r\n\r\n      <p>本次更新针对生成功能做了优化:</p>\r\n\r\n      <p>\r\n        1. 使用超会账号进行10个以上的批量秒传生成时, 会弹窗提示设置生成间隔,\r\n        防止生成过快导致接口被限制(#403)\r\n      </p>\r\n\r\n      <p>\r\n        2. 为秒传分享者提供了一份<a href=\"https://mengzonefire.code.misakanet.cn/rapid-upload-userscript-doc/generate-bdcode/\"\r\n          rel=\"noopener noreferrer\" target=\"_blank\">分享教程</a>用于参考\r\n      </p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.4.5 更新内容(21.1.12):</p>\r\n\r\n      <p>修复了1.4.0后可能出现的秒传按钮无效、显示多个秒传按钮的问题</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.3.7 更新内容(21.1.3):</p>\r\n\r\n      <p>修复了会员账号生成50M以下文件时提示 \"md5获取失败\" 的问题</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.3.3 更新内容(20.12.1):</p>\r\n\r\n      <p>\r\n        秒传生成完成后点击复制按钮之前都可以继续任务,防止误操作关闭页面导致生成结果丢失\r\n      </p>\r\n\r\n      <p>修改代码执行顺序防止秒传按钮出现在最左端</p>\r\n\r\n      <p>修复了跨域提示中失效的说明图片</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.2.9 更新内容(20.11.11):</p>\r\n\r\n      <p>生成秒传的弹窗添加了关闭按钮</p>\r\n\r\n      <p>删除了全部生成失败时的复制和测试按钮</p>\r\n\r\n      <p>秒传生成后加了一个导出文件路径的选项(默认不导出)</p>\r\n\r\n      <p>在输入保存路径的弹窗添加了校验, 防止输入错误路径</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.2.5 更新内容(20.11.4):</p>\r\n\r\n      <p>优化按钮样式, 添加了md5获取失败的报错</p>\r\n\r\n      <p>修复从pan.baidu.com进入后不显示生成按钮的问题</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>1.2.4 更新内容(20.11.2):</p>\r\n\r\n      <p>新增生成秒传:</p>\r\n\r\n      <p>选择文件或文件夹后点击 \"生成秒传\" 即可开始生成</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>继续未完成任务:</p>\r\n\r\n      <p>若生成秒传期间关闭了网页, 再次点击 \"生成秒传\" 即可继续任务</p>\r\n\r\n      <p><br /></p>\r\n\r\n      <p>测试秒传功能:</p>\r\n\r\n      <p>\r\n        生成完成后, 点击\"测试\"按钮, 会自动转存并覆盖文件(文件内容不变),\r\n        以检测秒传有效性, 以及修复md5错误防止秒传失效\r\n      </p>\r\n    </span>\r\n  </div>\r\n</div>"

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ./src/common/const.tsx
var updateInfoVer = "2.2.0"; // 更新弹窗的版本, 有些没必要提示的小更新就不弹窗了
var swalCssVer = "1.7.4"; // 由于其他主题的Css代码会缓存到本地, 故更新主题包版本(url)时, 需要同时更新该字串以刷新缓存
var donateVer = "2.1.0"; // 用于检测可关闭的赞助提示的版本号
var feedbackVer = "2.1.0"; // 用于检测可关闭的反馈提示的版本号
var locUrl = location.href;
var baiduNewPage = "baidu.com/disk/main"; // 匹配新版度盘界面
var TAG = "[秒传链接提取 by mengzonefire]";
var homePage = "https://greasyfork.org/zh-CN/scripts/424574";
var donatePage = "https://afdian.net/@mengzonefire";
var ajaxError = 514; // 自定义ajax请求失败时的错误码(不能与http statusCode冲突)
var extCssUrl = {
    Default: "https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css",
    Dark: "https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.min.css",
    "WordPress Admin": "https://cdn.jsdelivr.net/npm/@sweetalert2/theme-wordpress-admin@5/wordpress-admin.min.css",
    "Material UI": "https://cdn.jsdelivr.net/npm/@sweetalert2/theme-material-ui@5/material-ui.min.css",
    Bulma: "https://cdn.jsdelivr.net/npm/@sweetalert2/theme-bulma@5/bulma.min.css",
    "Bootstrap 4": "https://cdn.jsdelivr.net/npm/@sweetalert2/theme-bootstrap-4/bootstrap-4.min.css",
}; // 各主题包对应的url
var appError = {
    missDepend: "\u5916\u90E8\u8D44\u6E90\u52A0\u8F7D\u5931\u8D25, \u8BF7\u524D\u5F80\u811A\u672C\u9875\u53CD\u9988:\n" + homePage,
    SwalCssInvalid: "\u6837\u5F0F\u5305\u6570\u636E\u9519\u8BEF, \u8BF7\u524D\u5F80\u811A\u672C\u9875\u53CD\u9988:\n" + homePage,
    SwalCssErrReq: "\u6837\u5F0F\u5305\u52A0\u8F7D\u5931\u8D25, \u8BF7\u524D\u5F80\u811A\u672C\u9875\u53CD\u9988:\n" + homePage + "\n\u9519\u8BEF\u4EE3\u7801: ",
}; // 主程序异常
var doc = {
    shareDoc: "https://mengzonefire.code.misakanet.cn/rapid-upload-userscript-doc/generate-bdcode/",
    linkTypeDoc: "https://mengzonefire.code.misakanet.cn/rapid-upload-userscript-doc/format-support/",
}; // 各文档url
var linkStyle = 'class="mzf_link" rel="noopener noreferrer" target="_blank"';
var btnStyle = 'class="mzf_btn" rel="noopener noreferrer" target="_blank"';
var bdlinkPattern = /#bdlink=([\da-zA-Z+/=]+)/; // b64可能出现的字符: 大小写字母a-zA-Z, 数字0-9, +, /, = (=用于末尾补位)
var htmlCheckMd5 = "<p class=\"mzf_text\">\u6D4B\u8BD5\u79D2\u4F20 \u53EF\u9632\u6B62\u79D2\u4F20\u5931\u6548<a id=\"check_md5_btn\" class=\"mzf_btn\"><span class=\"text\" style=\"width: auto;\">\u6D4B\u8BD5</span></a></p>";
var htmlDocument = "<p class=\"mzf_text\">\u79D2\u4F20\u65E0\u6548/md5\u83B7\u53D6\u5931\u8D25/\u9632\u548C\u8C10\u7B49 \u53EF\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + btnStyle + "><span class=\"text\" style=\"width: auto;\">\u5206\u4EAB\u6559\u7A0B</span></a></p>";
var htmlDonate = "<p id=\"mzf_donate\" class=\"mzf_text\">\u82E5\u559C\u6B22\u8BE5\u811A\u672C, \u53EF\u524D\u5F80 <a href=\"" + donatePage + "\" " + linkStyle + ">\u8D5E\u52A9\u9875</a> \u652F\u6301\u4F5C\u8005<a id=\"kill_donate\" class=\"mzf_btn\">\u4E0D\u518D\u663E\u793A</a></p>";
var htmlFeedback = "<p id=\"mzf_feedback\" class=\"mzf_text\">\u82E5\u6709\u4EFB\u4F55\u7591\u95EE, \u53EF\u524D\u5F80 <a href=\"" + homePage + "\" " + linkStyle + ">\u811A\u672C\u4E3B\u9875</a> \u53CD\u9988<a id=\"kill_feedback\" class=\"mzf_btn\">\u4E0D\u518D\u663E\u793A</a></p>";

;// CONCATENATED MODULE: ./src/common/initQueryLink.tsx

/**
 * @description: 从url中解析秒传链接
 */
function initQueryLink() {
    var bdlinkB64 = locUrl.match(bdlinkPattern);
    return bdlinkB64 ? bdlinkB64[1].fromBase64() : "";
}

;// CONCATENATED MODULE: ./src/common/duParser.tsx
/*
 * @Author: mengzonefire
 * @Date: 2021-08-26 12:01:28
 * @LastEditTime: 2022-01-07 07:51:31
 * @LastEditors: mengzonefire
 * @Description: 秒传链接解析器
 */
function DuParser() { }
DuParser.parse = function generalDuCodeParse(szUrl) {
    var r;
    if (szUrl.indexOf("bdpan") === 0) {
        r = DuParser.parseDu_v1(szUrl);
        r.ver = "PanDL";
    }
    else if (szUrl.indexOf("BaiduPCS-Go") === 0) {
        r = DuParser.parseDu_v2(szUrl);
        r.ver = "PCS-Go";
    }
    else if (szUrl.indexOf("BDLINK") === 0) {
        r = DuParser.parseDu_v3(szUrl);
        r.ver = "游侠 v1";
    }
    else {
        r = DuParser.parseDu_v4(szUrl);
        r.ver = "梦姬标准";
    }
    return r;
};
DuParser.parseDu_v1 = function parseDu_v1(szUrl) {
    return szUrl
        .replace(/\s*bdpan:\/\//g, " ")
        .trim()
        .split(" ")
        .map(function (z) {
        return z
            .trim()
            .fromBase64()
            .match(/([\s\S]+)\|([\d]{1,20})\|([\dA-Fa-f]{32})\|([\dA-Fa-f]{32})/);
    })
        .filter(function (z) {
        return z;
    })
        .map(function (info) {
        return {
            md5: info[3],
            md5s: info[4],
            size: info[2],
            path: info[1],
        };
    });
};
DuParser.parseDu_v2 = function parseDu_v2(szUrl) {
    return szUrl
        .split("\n")
        .map(function (z) {
        // unsigned long long: 0~18446744073709551615
        return z
            .trim()
            .match(/-length=([\d]{1,20}) -md5=([\dA-Fa-f]{32}) -slicemd5=([\dA-Fa-f]{32})[\s\S]+"([\s\S]+)"/);
    })
        .filter(function (z) {
        return z;
    })
        .map(function (info) {
        return {
            md5: info[2],
            md5s: info[3],
            size: info[1],
            path: info[4],
        };
    });
};
DuParser.parseDu_v3 = function parseDu_v3(szUrl) {
    var raw = atob(szUrl.slice(6).replace(/\s/g, ""));
    if (raw.slice(0, 5) !== "BDFS\x00") {
        return null;
    }
    var buf = new SimpleBuffer(raw);
    var ptr = 9;
    var arrFiles = [];
    var fileInfo, nameSize;
    var total = buf.readUInt(5);
    var i;
    for (i = 0; i < total; i++) {
        // 大小 (8 bytes)
        // MD5 + MD5S (0x20)
        // nameSize (4 bytes)
        // Name (unicode)
        fileInfo = {};
        fileInfo.size = buf.readULong(ptr + 0);
        fileInfo.md5 = buf.readHex(ptr + 8, 0x10);
        fileInfo.md5s = buf.readHex(ptr + 0x18, 0x10);
        nameSize = buf.readUInt(ptr + 0x28) << 1;
        fileInfo.nameSize = nameSize;
        ptr += 0x2c;
        fileInfo.path = buf.readUnicode(ptr, nameSize);
        arrFiles.push(fileInfo);
        ptr += nameSize;
    }
    return arrFiles;
};
DuParser.parseDu_v4 = function parseDu_v3(szUrl) {
    return szUrl
        .split("\n")
        .map(function (z) {
        return z
            .trim()
            .match(/^([\dA-Fa-f]{32})#(?:([\dA-Fa-f]{32})#)?([\d]{1,20})#([\s\S]+)/);
    })
        .filter(function (z) {
        return z;
    })
        .map(function (info) {
        return {
            // 标准码 / 短版标准码(无md5s)
            md5: info[1],
            md5s: info[2] || "",
            size: info[3],
            path: info[4],
        };
    });
};
/**
 * 一个简单的类似于 NodeJS Buffer 的实现.
 * 用于解析游侠度娘提取码。
 * @param {SimpleBuffer}
 */
function SimpleBuffer(str) {
    this.fromString(str);
}
SimpleBuffer.toStdHex = function toStdHex(n) {
    return ("0" + n.toString(16)).slice(-2);
};
SimpleBuffer.prototype.fromString = function fromString(str) {
    var len = str.length;
    this.buf = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
        this.buf[i] = str.charCodeAt(i);
    }
};
SimpleBuffer.prototype.readUnicode = function readUnicode(index, size) {
    if (size & 1) {
        size++;
    }
    var bufText = Array.prototype.slice
        .call(this.buf, index, index + size)
        .map(SimpleBuffer.toStdHex);
    var buf = [""];
    for (var i = 0; i < size; i += 2) {
        buf.push(bufText[i + 1] + bufText[i]);
    }
    return JSON.parse('"' + buf.join("\\u") + '"');
};
SimpleBuffer.prototype.readNumber = function readNumber(index, size) {
    var ret = 0;
    for (var i = index + size; i > index;) {
        ret = this.buf[--i] + ret * 256;
    }
    return ret;
};
SimpleBuffer.prototype.readUInt = function readUInt(index) {
    return this.readNumber(index, 4);
};
SimpleBuffer.prototype.readULong = function readULong(index) {
    return this.readNumber(index, 8);
};
SimpleBuffer.prototype.readHex = function readHex(index, size) {
    return Array.prototype.slice
        .call(this.buf, index, index + size)
        .map(SimpleBuffer.toStdHex)
        .join("");
};

// EXTERNAL MODULE: ./src/components/updateInfo.html
var updateInfo = __webpack_require__(184);
var updateInfo_default = /*#__PURE__*/__webpack_require__.n(updateInfo);
;// CONCATENATED MODULE: ./src/common/SwalConfig.tsx

// 各Swal弹窗的固定参数配置:
var SwalConfig = {
    inputView: {
        title: "请输入秒传&保存路径",
        showCancelButton: true,
        html: "<textarea id=\"mzf-rapid-input\" class=\"swal2-textarea\" placeholder=\"[\u652F\u6301\u6279\u91CF(\u6362\u884C\u5206\u9694)]\n[\u652F\u6301PanDL/\u6E38\u4FA0/\u6807\u51C6\u7801/GO\u683C\u5F0F]\n[\u53EF\u5728\u8BBE\u7F6E\u9875\u5F00\u542F\u76D1\u542C\u526A\u8D34\u677F,\u81EA\u52A8\u8F93\u5165\u79D2\u4F20]\n[\u8F93\u5165set\u8FDB\u5165\u8BBE\u7F6E\u9875][\u8F93\u5165gen\u8FDB\u5165\u751F\u6210\u9875]\" style=\"display: flex;\"></textarea>\n    <input id=\"mzf-path-input\" class=\"swal2-input\" placeholder=\"\u4FDD\u5B58\u8DEF\u5F84, \u793A\u4F8B: /GTA5/, \u7559\u7A7A\u4FDD\u5B58\u5728\u5F53\u524D\u76EE\u5F55\" style=\"display: flex;margin-top: 10px;\">",
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        customClass: { htmlContainer: "mzf_html_container" },
    },
    processView: {
        showCloseButton: true,
        showConfirmButton: false,
        allowOutsideClick: false,
    },
    finishView: {
        showCloseButton: true,
        allowOutsideClick: false,
    },
    genUnfinish: {
        title: "检测到未完成的秒传任务",
        text: "是否继续进行?",
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "是",
        cancelButtonText: "否",
    },
    genView: {
        title: "请输入需要生成的文件路径",
        input: "textarea",
        showCancelButton: true,
        showCloseButton: true,
        inputPlaceholder: "[支持批量(换行分隔)]",
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        inputValidator: function (value) {
            if (!value) {
                return "文件路径不能为空";
            }
        },
    },
    updateInfo: {
        title: "\u79D2\u4F20\u94FE\u63A5\u63D0\u53D6 \u66F4\u65B0\u5185\u5BB9",
        showCloseButton: true,
        allowOutsideClick: false,
        confirmButtonText: "知道了",
        html: (updateInfo_default()),
    },
    checkRecursive: {
        icon: "info",
        title: "包含文件夹, 是否递归生成?",
        text: "若选是, 将同时生成各级子文件夹下的文件",
        allowOutsideClick: false,
        focusCancel: true,
        showCancelButton: true,
        reverseButtons: true,
        showCloseButton: true,
        confirmButtonText: "是",
        cancelButtonText: "否",
    },
    checkMd5Warning: {
        title: "使用前请注意",
        text: "测试秒传会转存并覆盖文件,若在生成期间修改过同名文件,为避免修改的文件丢失,请不要使用此功能!",
        input: "checkbox",
        inputPlaceholder: "不再显示",
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "确定",
        cancelButtonText: "返回",
    },
    settingView: {
        title: "秒传链接提取 设置页",
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        allowOutsideClick: false,
        html: "<select class=\"swal2-select\" id=\"mzf-theme\" style=\"display: flex;border-width: 1px;border-style: solid;\"><option value=\"Default\">Default \u767D\u8272\u4E3B\u9898(\u9ED8\u8BA4)</option><option value=\"Bulma\">Bulma \u767D\u8272\u7B80\u7EA6</option><option value=\"Bootstrap 4\">Bootstrap4 \u767D\u8272\u7B80\u7EA6</option><option value=\"Material UI\">MaterialUI \u767D\u8272\u4E3B\u9898</option><option value=\"Dark\">Dark \u9ED1\u8272\u4E3B\u9898</option><option value=\"WordPress Admin\">WordPressAdmin \u7070\u8272\u4E3B\u9898</option></select>\n    <label for=\"swal2-checkbox\" class=\"swal2-checkbox\" style=\"display: flex;\"><span class=\"swal2-label\">\u76D1\u542C\u526A\u8D34\u677F (\u9700\u8981\u5141\u8BB8\u526A\u8D34\u677F\u6743\u9650)</span><input type=\"checkbox\" value=\"1\" id=\"mzf-listen-clipboard\" style=\"margin-left: 20px;\"></label>",
    },
    settingWarning: {
        title: "设置成功 刷新页面生效",
        showCloseButton: true,
        allowOutsideClick: false,
        confirmButtonText: "知道了",
    },
    selectNoFileWarning: {
        title: "请勾选要生成秒传的文件/文件夹",
        icon: "error",
        showCloseButton: true,
        confirmButtonText: "知道了",
    },
};

;// CONCATENATED MODULE: ./src/common/utils.tsx
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};



/**
 * @description: 弹出一个文本提示框
 * @param {string} text
 */
function showAlert(text) {
    alert(TAG + ":\n" + text);
}
/**
 * @description: md5随机大小写
 * @param {string} string
 * @return {string}
 */
function randomStringTransform(string) {
    var tempString = [];
    for (var _i = 0, string_1 = string; _i < string_1.length; _i++) {
        var i = string_1[_i];
        if (!Math.round(Math.random())) {
            tempString.push(i.toLowerCase());
        }
        else {
            tempString.push(i.toUpperCase());
        }
    }
    return tempString.join("");
}
/**
 * @description: 解析文件信息, 返回转存结果列表html, 秒传链接, 失败文件个数, 成功的文件信息列表
 * @param {Array} fileInfoList
 */
function parsefileInfo(fileInfoList) {
    var bdcode = "";
    var successInfo = "";
    var failedInfo = "";
    var failedCount = 0;
    var successList = [];
    fileInfoList.forEach(function (item) {
        if (item.errno) {
            failedCount++;
            failedInfo += "<p>\u6587\u4EF6\uFF1A" + item.path + "</p><p>\u5931\u8D25\u539F\u56E0\uFF1A" + baiduErrno(item.errno) + "(#" + item.errno + ")</p>";
        }
        else {
            successInfo += "<p>\u6587\u4EF6\uFF1A" + item.path + "</p>";
            bdcode += item.md5 + "#" + item.md5s + "#" + item.size + "#" + item.path + "\n";
            successList.push(item);
        }
    });
    if (failedInfo)
        failedInfo = "<details class=\"mzf_details\"><summary><svg width=\"16\" height=\"7\"><polyline points=\"0,0 8,7 16,0\"/></svg><b>\u5931\u8D25\u6587\u4EF6\u5217\u8868(\u70B9\u51FB\u5C55\u5F00):</b></summary></details><div class=\"mzf_content\">" + failedInfo + "</div>";
    if (successInfo)
        successInfo = "<details class=\"mzf_details\"><summary><svg width=\"16\" height=\"7\"><polyline points=\"0,0 8,7 16,0\"/></svg><b>\u6210\u529F\u6587\u4EF6\u5217\u8868(\u70B9\u51FB\u5C55\u5F00):</b></summary></details><div class=\"mzf_content\">" + successInfo + "</div>";
    bdcode = bdcode.trim();
    return {
        htmlInfo: successInfo && failedInfo
            ? successInfo + "<p><br /></p>" + failedInfo
            : successInfo + failedInfo,
        failedCount: failedCount,
        bdcode: bdcode,
        successList: successList,
    };
}
/**
 * @description: 获取选择的文件列表(旧版界面)
 */
function getSelectedFileListLegacy() {
    return unsafeWindow
        .require("system-core:context/context.js")
        .instanceForSystem.list.getSelected();
}
/**
 * @description: 获取选择的文件列表(新版界面)
 * 我从这里抄的, 谢谢你: https://greasyfork.org/zh-CN/scripts/436446
 */
function getSelectedFileListNew() {
    return document.querySelector(".nd-main-list").__vue__.selectedList;
}
/**
 * @description: 将data键值对转换为query字符串
 * @param {any} data
 * @return {string} query string
 */
function convertData(data) {
    var query = "";
    for (var key in data)
        query += "&" + key + "=" + encodeURIComponent(data[key]);
    return query;
}
function parseClipboard() {
    return __awaiter(this, void 0, void 0, function () {
        var bdlink, error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, navigator.clipboard.readText()];
                case 1:
                    bdlink = _a.sent();
                    if (!DuParser.parse(bdlink).length)
                        return [2 /*return*/, ""];
                    return [2 /*return*/, bdlink];
                case 2:
                    error_1 = _a.sent();
                    showAlert('使用 "监听剪贴板" 功能需要允许剪贴板权限!');
                    return [2 /*return*/, ""];
                case 3: return [2 /*return*/];
            }
        });
    });
}

;// CONCATENATED MODULE: ./src/common/swalBase.tsx
/*
 * @Author: mengzonefire
 * @Date: 2021-08-25 08:34:46
 * @LastEditTime: 2022-03-24 20:52:12
 * @LastEditors: mengzonefire
 * @Description: 定义全套的前台弹窗逻辑, 在Swal的回调函数内调用***Task类内定义的任务代码
 */
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var swalBase_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var swalBase_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};






var Swalbase = /** @class */ (function () {
    function Swalbase(rapiduploadTask, generatebdlinkTask) {
        this.rapiduploadTask = rapiduploadTask;
        this.generatebdlinkTask = generatebdlinkTask;
    }
    // 合并swal参数
    Swalbase.prototype.mergeArg = function () {
        var inputArgs = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            inputArgs[_i] = arguments[_i];
        }
        var output = {};
        var swalCfgArgs = {
            // 禁用backdrop动画, 阻止多次弹窗时的屏闪
            showClass: { backdrop: "swal2-noanimation" },
            hideClass: { backdrop: "swal2-noanimation" },
        };
        $.extend.apply($, __spreadArray([output, this.swalGlobalArgs, swalCfgArgs], inputArgs));
        return output;
    };
    // 点击 "秒传链接" 后显示的弹窗
    Swalbase.prototype.inputView = function (bdlink) {
        if (bdlink === void 0) { bdlink = ""; }
        return swalBase_awaiter(this, void 0, void 0, function () {
            var rapidValue, pathValue, preConfirm, willOpen;
            var _this = this;
            return swalBase_generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        rapidValue = bdlink;
                        // 从GM存储读取之前输入的路径数据&从剪贴板读取有效的秒传数据
                        console.log(GM_getValue("listen-clipboard"));
                        if (!(GM_getValue("listen-clipboard") && !rapidValue)) return [3 /*break*/, 2];
                        return [4 /*yield*/, parseClipboard()];
                    case 1:
                        rapidValue = _a.sent();
                        _a.label = 2;
                    case 2:
                        pathValue = GM_getValue("last_dir") || "";
                        preConfirm = function () {
                            rapidValue = $("#mzf-rapid-input")[0].value;
                            pathValue = $("#mzf-path-input")[0].value;
                            if (!rapidValue) {
                                Swal.showValidationMessage("秒传不能为空");
                                return false;
                            }
                            if (rapidValue === "set") {
                                return;
                            }
                            if (rapidValue === "gen") {
                                return;
                            }
                            if (!DuParser.parse(rapidValue).length) {
                                Swal.showValidationMessage("<p>\u672A\u8BC6\u522B\u5230\u6B63\u786E\u7684\u94FE\u63A5 <a href=\"" + doc.linkTypeDoc + "\" " + linkStyle + ">\u67E5\u770B\u652F\u6301\u683C\u5F0F</a></p>");
                                return false;
                            }
                            if (pathValue.match(illegalPathPattern)) {
                                Swal.showValidationMessage('保存路径不能含有字符\\":*?<>|, 示例：/GTA5/');
                                return false;
                            }
                        };
                        willOpen = function () {
                            $("#swal2-html-container")
                                .css("font-size", "1rem")
                                .css("display", "grid")
                                .css("margin", "0");
                            $("#mzf-rapid-input")[0].value = rapidValue;
                            $("#mzf-path-input")[0].value = pathValue;
                        };
                        Swal.fire(this.mergeArg(SwalConfig.inputView, {
                            preConfirm: preConfirm,
                            willOpen: willOpen,
                        })).then(function (result) {
                            if (result.isConfirmed) {
                                if (rapidValue === "set")
                                    _this.settingView();
                                else if (rapidValue === "gen")
                                    _this.genView();
                                else {
                                    _this.rapiduploadTask.reset();
                                    _this.rapiduploadTask.fileInfoList = DuParser.parse(rapidValue);
                                    GM_setValue("last_dir", pathValue);
                                    if (!pathValue) {
                                        // 路径留空
                                        _this.rapiduploadTask.isDefaultPath = true;
                                        var nowPath = location.href.match(/path=(.+?)(?:&|$)/);
                                        if (nowPath)
                                            pathValue = decodeURIComponent(nowPath[1]);
                                        else
                                            pathValue = "/";
                                    }
                                    if (pathValue.charAt(pathValue.length - 1) !== "/")
                                        pathValue += "/"; // 补全路径结尾的 "/"
                                    console.log("\u79D2\u4F20\u6587\u4EF6\u4FDD\u5B58\u5230: " + pathValue); // debug
                                    _this.rapiduploadTask.savePath = pathValue;
                                    _this.processView(false);
                                }
                            }
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    // 转存/生成过程中的弹窗
    Swalbase.prototype.processView = function (isGen) {
        var _this = this;
        var swalArg = {
            title: isGen
                ? "秒传生成中"
                : "\u6587\u4EF6" + (this.rapiduploadTask.checkMode ? "测试" : "提取") + "\u4E2D",
            html: isGen
                ? "<p>正在生成第 <file_num>0</file_num> 个</p><p><gen_prog>正在获取文件列表...</gen_prog></p>"
                : "\u6B63\u5728" + (this.rapiduploadTask.checkMode ? "测试" : "转存") + "\u7B2C <file_num>0</file_num> \u4E2A",
            willOpen: function () {
                Swal.showLoading();
                isGen || _this.saveFileWork();
            },
        };
        Swal.fire(this.mergeArg(SwalConfig.processView, swalArg));
    };
    // 转存/生成/测试秒传完成的弹窗
    Swalbase.prototype.finishView = function (isGen) {
        var _this = this;
        var action = isGen
            ? "生成"
            : this.rapiduploadTask.checkMode
                ? "测试"
                : "转存";
        var fileInfoList = isGen
            ? this.generatebdlinkTask.fileInfoList
            : this.rapiduploadTask.fileInfoList;
        var parseResult = parsefileInfo(fileInfoList);
        if (isGen)
            this.rapiduploadTask.fileInfoList = parseResult.successList;
        var checkboxArg = parseResult.failedCount === fileInfoList.length
            ? {}
            : {
                input: "checkbox",
                inputValue: GM_getValue("with_path"),
                inputPlaceholder: "导出文件夹目录结构",
            }; // 全部失败不显示此checkbox
        var html = (isGen
            ? (parseResult.failedCount === fileInfoList.length
                ? ""
                : htmlCheckMd5) + // 添加测试秒传入口, 若全部失败则不添加
                htmlDocument // 添加文档入口
            : "") +
            (parseResult.htmlInfo && isGen ? "<p><br></p>" : "") +
            parseResult.htmlInfo; // 添加失败列表, 生成模式下添加顶部空行分隔
        var htmlFooter = "";
        if (!GM_getValue(donateVer + "_kill_donate"))
            htmlFooter += htmlDonate; // 添加赞助入口提示
        if (!GM_getValue(feedbackVer + "_kill_donate"))
            htmlFooter += htmlFeedback; // 添加反馈入口提示
        if (htmlFooter)
            htmlFooter = "<p><br></p>" + htmlFooter; // 添加底部空行分隔
        var swalArg = __assign(__assign({ title: action + "\u5B8C\u6BD5 \u5171" + fileInfoList.length + "\u4E2A, \u5931\u8D25" + parseResult.failedCount + "\u4E2A!", confirmButtonText: parseResult.failedCount !== fileInfoList.length &&
                (isGen || this.rapiduploadTask.checkMode)
                ? "复制秒传代码"
                : "确认", html: html + htmlFooter }, ((isGen || this.rapiduploadTask.checkMode) && checkboxArg)), { willOpen: function () {
                if (!isGen && !_this.rapiduploadTask.checkMode)
                    _this.addOpenDirBtn(); // 转存模式时添加 "打开目录" 按钮
            } });
        Swal.fire(this.mergeArg(SwalConfig.finishView, swalArg)).then(function (result) {
            if (result.isConfirmed) {
                if (isGen || _this.rapiduploadTask.checkMode) {
                    // 生成/测试模式, "复制秒传代码"按钮
                    GM_setValue("with_path", result.value);
                    if (!result.value)
                        GM_setClipboard(parseResult.bdcode.replace(/\/.+\//g, ""));
                    // 去除秒传链接中的目录结构(仅保留文件名)
                    else
                        GM_setClipboard(parseResult.bdcode); // 保留完整的文件路径
                    GM_deleteValue("unfinish"); // 清除任务进度数据
                }
                else {
                    // 转存模式, "确定" 按钮
                    refreshList(); // 调用刷新文件列表的方法
                }
            }
        });
    };
    // 生成文件夹秒传, 是否递归生成提示
    Swalbase.prototype.checkRecursive = function () {
        var _this = this;
        Swal.fire(this.mergeArg(SwalConfig.checkRecursive)).then(function (result) {
            if (result.isConfirmed) {
                _this.generatebdlinkTask.recursive = true;
            }
            else if (result.dismiss === Swal.DismissReason.cancel)
                _this.generatebdlinkTask.recursive = false;
            else
                return;
            _this.processView(true);
            _this.generatebdlinkTask.scanFile(0);
        });
    };
    // 设置页
    Swalbase.prototype.settingView = function () {
        var _this = this;
        var willOpen = function () {
            $("#swal2-html-container")
                .css("font-size", "1rem")
                .css("display", "grid")
                .css("margin", "0");
            $("#mzf-theme")[0].value = GM_getValue("swalThemes") || "Default";
            $("#mzf-listen-clipboard")[0].checked = Boolean(GM_getValue("listen-clipboard"));
        };
        var preConfirm = function () { return swalBase_awaiter(_this, void 0, void 0, function () {
            var error_1;
            return swalBase_generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        GM_setValue("swalThemes", $("#mzf-theme")[0].value);
                        if (!$("#mzf-listen-clipboard")[0].checked) return [3 /*break*/, 4];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, navigator.clipboard.readText()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        showAlert('开启 "监听剪贴板" 功能需要允许剪贴板权限!');
                        return [2 /*return*/];
                    case 4:
                        GM_setValue("listen-clipboard", $("#mzf-listen-clipboard")[0].checked);
                        return [2 /*return*/];
                }
            });
        }); };
        Swal.fire(this.mergeArg(SwalConfig.settingView, {
            willOpen: willOpen,
            preConfirm: preConfirm,
        })).then(function (result) {
            if (result.isConfirmed)
                Swal.fire(_this.mergeArg(SwalConfig.settingWarning));
        });
    };
    // 生成页 (输入路径列表进行秒传生成)
    Swalbase.prototype.genView = function () {
        var _this = this;
        Swal.fire(this.mergeArg(SwalConfig.genView)).then(function (result) {
            if (result.isConfirmed) {
                _this.generatebdlinkTask.reset();
                result.value.split("\n").forEach(function (item) {
                    if (item.charAt(0) !== "/")
                        item = "/" + item;
                    _this.generatebdlinkTask.fileInfoList.push({
                        path: item,
                    });
                });
                _this.processView(true); // 显示进度弹窗
                _this.genFileWork(false, true); // 跳过获取选择文件列表和扫描文件夹的步骤
                _this.generatebdlinkTask.generateBdlink(0); // 开始生成任务
            }
        });
    };
    // 生成秒传未完成任务提示
    Swalbase.prototype.genUnfinishi = function (onConfirm, onCancel) {
        Swal.fire(this.mergeArg(SwalConfig.genUnfinish)).then(function (result) {
            if (result.isConfirmed)
                onConfirm();
            else if (result.dismiss === Swal.DismissReason.cancel)
                onCancel();
        });
    };
    // 测试秒传覆盖文件提示
    Swalbase.prototype.checkMd5Warning = function (onConfirm, onCancel) {
        Swal.fire(this.mergeArg(SwalConfig.checkMd5Warning)).then(function (result) {
            if (result.isConfirmed) {
                GM_setValue("check_md5_warning", result.value);
                onConfirm();
            }
            else if (result.dismiss === Swal.DismissReason.cancel)
                onCancel();
        });
    };
    // 生成秒传, 未选择任何文件的提示
    Swalbase.prototype.selectNoFileWarning = function () {
        Swal.fire(this.mergeArg(SwalConfig.selectNoFileWarning));
    };
    // 更新信息页
    Swalbase.prototype.updateInfo = function (onConfirm) {
        Swal.fire(this.mergeArg(SwalConfig.updateInfo)).then(function (result) {
            if (result.isConfirmed)
                onConfirm();
        });
    };
    // 以下的方法都是任务操作逻辑, 不是弹窗逻辑
    Swalbase.prototype.saveFileWork = function () {
        var _this = this;
        this.rapiduploadTask.onFinish = function () {
            _this.finishView(false);
        };
        this.rapiduploadTask.onProcess = function (i, fileInfoList) {
            Swal.getHtmlContainer().querySelector("file_num").textContent = i + 1 + " / " + fileInfoList.length;
        };
        this.rapiduploadTask.start(); // 开始转存任务
    };
    Swalbase.prototype.genFileWork = function (isUnfinish, isGenView) {
        var _this = this;
        if (!isGenView)
            this.generatebdlinkTask.selectList = getSelectedFileList();
        if (!this.generatebdlinkTask.selectList.length) {
            this.selectNoFileWarning();
            return;
        }
        this.generatebdlinkTask.onProcess = function (i, fileInfoList) {
            Swal.getHtmlContainer().querySelector("file_num").textContent = i + 1 + " / " + fileInfoList.length;
            Swal.getHtmlContainer().querySelector("gen_prog").textContent = "0%";
        };
        this.generatebdlinkTask.onProgress = function (e) {
            if (typeof e.total !== "number")
                return; // 参数数据不正确 跳过
            Swal.getHtmlContainer().querySelector("gen_prog").textContent = ((e.loaded / e.total) *
                100).toFixed() + "%";
        };
        this.generatebdlinkTask.onHasNoDir = function () {
            _this.processView(true);
            _this.generatebdlinkTask.generateBdlink(0);
        };
        this.generatebdlinkTask.onHasDir = function () {
            _this.checkRecursive();
        };
        this.generatebdlinkTask.onFinish = function () {
            _this.finishView(true);
        };
        if (!isUnfinish && !isGenView)
            this.generatebdlinkTask.start(); // 执行新任务初始化
    };
    Swalbase.prototype.checkUnfinish = function () {
        var _this = this;
        if (GM_getValue("unfinish")) {
            this.genUnfinishi(function () {
                _this.processView(true);
                _this.genFileWork(true, false);
                var unfinishInfo = GM_getValue("unfinish");
                _this.generatebdlinkTask.fileInfoList = unfinishInfo.file_info_list;
                _this.generatebdlinkTask.generateBdlink(unfinishInfo.file_id);
            }, // 确认继续未完成任务
            function () {
                GM_deleteValue("unfinish");
                _this.genFileWork(false, false);
            } // 不继续未完成任务, 清除数据, 开启新任务
            );
        }
        else {
            this.genFileWork(false, false);
        } // 没有未完成任务, 直接开启新任务
    };
    Swalbase.prototype.checkMd5 = function () {
        var _this = this;
        this.rapiduploadTask.checkMode = true;
        if (!GM_getValue("check_md5_warning")) {
            this.checkMd5Warning(function () {
                _this.processView(false);
            }, // 点击确定按钮, 开始测试转存
            function () {
                _this.finishView(true);
            } // 点击返回按钮, 回到生成完成的界面
            );
        }
        else
            this.processView(false); // 已勾选"不再提示", 直接开始测试转存
    };
    // 添加 "打开目录" 按钮
    Swalbase.prototype.addOpenDirBtn = function () {
        if (!this.rapiduploadTask.isDefaultPath) {
            var _dir_1 = (this.rapiduploadTask.savePath || "").replace(/\/$/, ""); // 去除路径结尾的"/"
            if (_dir_1.charAt(0) !== "/")
                _dir_1 = "/" + _dir_1; // 补齐路径开头的"/"
            var cBtn = Swal.getConfirmButton();
            var btn = cBtn.cloneNode();
            btn.textContent = "打开目录";
            btn.style.backgroundColor = "#ecae3c";
            btn.onclick = function () {
                var path = location.href.match(/(path=(.+?))(?:&|$)/);
                if (path) {
                    if (path[2] !== encodeURIComponent(_dir_1))
                        location.href = location.href.replace(
                        // 仅替换path参数, 不修改其他参数
                        path[1], "path=" + encodeURIComponent(_dir_1));
                    else
                        refreshList(); // path参数相同, 已在目标目录下, 调用刷新函数
                }
                else {
                    var connectChar = location.href.indexOf("?") === -1 ? "?" : "&"; // 确定参数的连接符
                    location.href += connectChar + "path=" + encodeURIComponent(_dir_1);
                } // 没有找到path参数, 直接添加
                Swal.close();
            };
            cBtn.before(btn);
        }
    };
    return Swalbase;
}());
/* harmony default export */ const swalBase = (Swalbase);

;// CONCATENATED MODULE: ./src/common/ajax.tsx
/*
 * @Author: mengzonefire
 * @Date: 2021-08-27 14:48:24
 * @LastEditTime: 2021-10-18 15:34:58
 * @LastEditors: mengzonefire
 * @Description: 自封装JQ ajax方法
 */
var ajax_assign = (undefined && undefined.__assign) || function () {
    ajax_assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return ajax_assign.apply(this, arguments);
};

function ajax(config, callback, failback) {
    GM_xmlhttpRequest(ajax_assign(ajax_assign({}, config), { onload: function (r) {
            // console.log(r); // debug
            if (Math.floor(r.status / 100) === 2)
                callback(r);
            else
                failback(r.status);
        }, onerror: function () {
            failback(ajaxError);
        } }));
}

;// CONCATENATED MODULE: ./src/baidu/common/GeneratebdlinkTask.tsx
/*
 * @Author: mengzonefire
 * @Date: 2021-08-25 01:31:01
 * @LastEditTime: 2021-11-12 11:23:42
 * @LastEditors: mengzonefire
 * @Description: 百度网盘 秒传生成任务实现
 */


var GeneratebdlinkTask = /** @class */ (function () {
    function GeneratebdlinkTask() {
    }
    GeneratebdlinkTask.prototype.reset = function () {
        this.recursive = false;
        this.dirList = [];
        this.selectList = [];
        this.fileInfoList = [];
        this.onFinish = function () { };
        this.onProcess = function () { };
        this.onProgress = function () { };
        this.onHasDir = function () { };
        this.onHasNoDir = function () { };
    };
    /**
     * @description: 执行新任务的初始化步骤 扫描选择的文件列表
     */
    GeneratebdlinkTask.prototype.start = function () {
        var _this = this;
        this.selectList.forEach(function (item) {
            if (item.isdir)
                _this.dirList.push(item.path);
            else {
                _this.fileInfoList.push({
                    path: item.path,
                    size: item.size,
                });
            }
        });
        if (this.dirList.length)
            this.onHasDir();
        else
            this.onHasNoDir();
    };
    /**
     * @description: 选择的列表包含文件夹, 获取文件夹下的子文件
     * @param {number} i
     */
    GeneratebdlinkTask.prototype.scanFile = function (i) {
        var _this = this;
        if (i >= this.dirList.length) {
            this.generateBdlink(0);
            return;
        }
        ajax({
            url: list_url + "&path=" + encodeURIComponent(this.dirList[i]) + "&recursion=" + (this.recursive ? 1 : 0),
            method: "GET",
            responseType: "json",
        }, function (data) {
            data = data.response;
            if (!data.errno) {
                data.list.forEach(function (item) {
                    item.isdir || _this.fileInfoList.push({ path: item.path }); // 筛选并添加文件 (isdir===0)
                });
            }
            else
                _this.fileInfoList.push({
                    path: _this.dirList[i],
                    errno: data.errno,
                });
            _this.scanFile(i + 1);
        }, function (statusCode) {
            _this.fileInfoList.push({
                path: _this.dirList[i],
                errno: statusCode === 500 ? 901 : statusCode,
            });
            _this.scanFile(i + 1);
        });
    };
    /**
     * @description: 获取秒传链接需要的信息
     * @param {number} i
     * @param {number} tryFlag
     * @return {*}
     */
    GeneratebdlinkTask.prototype.generateBdlink = function (i) {
        GM_setValue("unfinish", {
            file_info_list: this.fileInfoList,
            file_id: i,
        }); // 保存任务进度数据
        if (i >= this.fileInfoList.length) {
            this.onFinish(this.fileInfoList);
            return;
        }
        this.onProcess(i, this.fileInfoList);
        var file = this.fileInfoList[i];
        if (file.errno) {
            this.generateBdlink(i + 1);
            return;
        } // 跳过扫描失败的文件夹
        this.getFileInfo(i);
    };
    /**
     * @description: 获取文件信息: size, md5(可能错误), fs_id
     * @param {number} i
     */
    GeneratebdlinkTask.prototype.getFileInfo = function (i) {
        var _this = this;
        var file = this.fileInfoList[i];
        ajax({
            url: meta_url + encodeURIComponent(file.path),
            responseType: "json",
            method: "GET",
        }, function (data) {
            data = data.response;
            if (!data.errno) {
                console.log(data.list[0]); // debug
                if (data.list[0].isdir) {
                    file.errno = 900;
                    _this.generateBdlink(i + 1);
                    return;
                }
                file.size = data.list[0].size;
                file.fs_id = data.list[0].fs_id;
                // meta接口获取的md5可能错误, 故不再使用
                // let md5 = data.list[0].md5.match(/[\dA-Fa-f]{32}/);
                // if (md5) file.md5 = md5[0].toLowerCase(); // 获取到正确的md5
                if (data.list[0].block_list.length === 1)
                    // block_list内获取到正确的md5
                    file.md5 = data.list[0].block_list[0].toLowerCase();
                // 测试旧下载接口_start
                // file.retry_996 = true;
                // this.downloadFileData(
                //   i,
                //   pcs_url + `&path=${encodeURIComponent(file.path)}`
                // );
                // return;
                // 测试旧下载接口_end
                _this.getDlink(i);
            }
            else {
                file.errno = data.errno;
                _this.generateBdlink(i + 1);
            }
        }, function (statusCode) {
            file.errno = statusCode === 404 ? 909 : statusCode;
            _this.generateBdlink(i + 1);
        });
    };
    /**
     * @description: 获取文件的下载链接
     * @param {number} i
     */
    GeneratebdlinkTask.prototype.getDlink = function (i) {
        var _this = this;
        var file = this.fileInfoList[i];
        ajax({
            url: meta_url2 + JSON.stringify([file.fs_id]),
            responseType: "json",
            method: "GET",
        }, function (data) {
            data = data.response;
            if (!data.errno) {
                console.log(data.list[0]); // debug
                _this.downloadFileData(i, data.list[0].dlink);
            }
            else {
                file.errno = data.errno;
                _this.generateBdlink(i + 1);
            }
        }, function (statusCode) {
            file.errno = statusCode;
            _this.generateBdlink(i + 1);
        });
    };
    /**
     * @description: 调用下载直链
     * @param {number} i
     * @param {string} dlink
     */
    GeneratebdlinkTask.prototype.downloadFileData = function (i, dlink) {
        var _this = this;
        var file = this.fileInfoList[i];
        var dlSize = file.size < 262144 ? file.size - 1 : 262143; //slice-md5: 文件前256KiB的md5
        ajax({
            url: dlink,
            method: "GET",
            responseType: "arraybuffer",
            headers: {
                Range: "bytes=0-" + dlSize,
                "User-Agent": UA,
            },
            onprogress: this.onProgress,
        }, function (data) {
            _this.onProgress({ loaded: 100, total: 100 }); // 100%
            _this.parseDownloadData(i, data);
        }, function (statusCode) {
            if (statusCode === 404)
                file.errno = 909;
            else
                file.errno = statusCode;
            _this.generateBdlink(i + 1);
        });
    };
    /**
     * @description: 解析服务器返回的数据
     * @param {number} i
     * @param {JQuery.jqXHR} xhr
     * @return {*}
     */
    GeneratebdlinkTask.prototype.parseDownloadData = function (i, data) {
        var _this = this;
        console.log("dl_url: " + data.finalUrl); // debug
        var file = this.fileInfoList[i];
        if (data.finalUrl.indexOf("issuecdn.baidupcs.com") !== -1) {
            file.errno = 1919;
            this.generateBdlink(i + 1);
            return;
        }
        else {
            // console.log(data.responseHeaders); // debug
            var fileMd5 = data.responseHeaders.match(/content-md5: ([\da-f]{32})/i);
            if (fileMd5)
                file.md5 = fileMd5[1].toLowerCase();
            // 从下载接口拿到了md5, 会覆盖meta接口的md5
            else if (!file.md5 && file.size <= 3900000000 && !file.retry_996) {
                // 下载接口和meta接口均未拿到md5, 尝试使用旧下载接口
                file.retry_996 = true;
                this.downloadFileData(i, pcs_url + ("&path=" + encodeURIComponent(file.path)));
                return;
            }
            else if (!file.md5) {
                // 两个下载接口和meta接口均未拿到md5
                file.errno = 996;
                this.generateBdlink(i + 1);
                return;
            }
            var spark = new SparkMD5.ArrayBuffer();
            spark.append(data.response);
            var sliceMd5 = spark.end();
            file.md5s = sliceMd5;
            var interval = this.fileInfoList.length > 1 ? 2000 : 1000;
            setTimeout(function () {
                _this.generateBdlink(i + 1);
            }, interval);
        }
    };
    return GeneratebdlinkTask;
}());
/* harmony default export */ const common_GeneratebdlinkTask = (GeneratebdlinkTask);

;// CONCATENATED MODULE: ./src/baidu/common/RapiduploadTask.tsx
/*
 * @Author: mengzonefire
 * @Date: 2021-08-25 01:30:29
 * @LastEditTime: 2022-04-13 19:01:20
 * @LastEditors: mengzonefire
 * @Description: 百度网盘 秒传转存任务实现
 */



var RapiduploadTask = /** @class */ (function () {
    function RapiduploadTask() {
    }
    RapiduploadTask.prototype.reset = function () {
        this.bdstoken = getBdstoken();
        console.log("bdstoken: ", this.bdstoken); // debug
        this.fileInfoList = [];
        this.savePath = "";
        this.checkMode = false;
        this.isDefaultPath = false;
        this.onFinish = function () { };
        this.onProcess = function () { };
    };
    RapiduploadTask.prototype.start = function () {
        if (this.checkMode)
            this.savePath = "";
        this.saveFile(0, 0 /* useUpperCaseMd5 */);
    };
    /**
     * @description: 转存秒传 接口1
     * @param {number} i
     * @param {number} tryFlag 标识参数
     */
    RapiduploadTask.prototype.saveFile = function (i, tryFlag) {
        var _this = this;
        if (i >= this.fileInfoList.length) {
            this.onFinish(this.fileInfoList);
            return;
        }
        this.onProcess(i, this.fileInfoList);
        var file = this.fileInfoList[i];
        // 文件名含有非法字符 / 文件名为空
        if (file.path.match(/["\\\:*?<>|]/) || file.path === "/") {
            file.errno = 2333;
            this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
            return;
        }
        // 短版标准码(无slice-md5) 或 20GB以上的文件, 使用秒传v2接口转存
        if (!file.md5s || file.size > 21474836480) {
            file.md5 = file.md5.toLowerCase();
            this.saveFileV2(i);
            return;
        }
        switch (tryFlag) {
            case 0 /* useUpperCaseMd5 */:
                console.log("use UpperCase md5");
                file.md5 = file.md5.toUpperCase();
                break;
            case 1 /* useLowerCaseMd5 */:
                console.log("use LowerCase md5");
                file.md5 = file.md5.toLowerCase();
                break;
            case 2 /* useRandomCaseMd5 */:
                console.log("use randomCase md5");
                file.md5 = randomStringTransform(file.md5);
                break;
            case 3 /* useSaveFileV2 */:
                console.log("use saveFile v2");
                file.md5 = file.md5.toLowerCase();
                this.saveFileV2(i);
                return;
            default:
                this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
                return;
        }
        ajax({
            url: "" + rapid_url + (this.bdstoken && "?bdstoken=" + this.bdstoken),
            method: "POST",
            responseType: "json",
            data: convertData({
                rtype: this.checkMode ? 3 : 0,
                path: this.savePath + file.path,
                "content-md5": file.md5,
                "slice-md5": file.md5s.toLowerCase(),
                "content-length": file.size,
            }),
        }, function (data) {
            data = data.response;
            if (data.errno === 404)
                _this.saveFile(i, tryFlag + 1);
            else {
                file.errno = data.errno;
                _this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
            }
        }, function (statusCode) {
            file.errno = statusCode;
            _this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
        });
    };
    /**
     * @description: 转存秒传 接口2
     * @param {number} i
     */
    RapiduploadTask.prototype.saveFileV2 = function (i) {
        var _this = this;
        var file = this.fileInfoList[i];
        ajax({
            url: "" + create_url + (this.bdstoken && "&bdstoken=" + this.bdstoken),
            method: "POST",
            responseType: "json",
            data: convertData({
                block_list: JSON.stringify([file.md5]),
                path: this.savePath + file.path,
                size: file.size,
                isdir: 0,
                rtype: this.checkMode ? 3 : 0, // rtype=3覆盖文件, rtype=0则返回报错, 不覆盖文件, 默认为1(自动重命名)
            }),
        }, function (data) {
            data = data.response;
            file.errno = data.errno === 2 ? 404 : data.errno;
            _this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
        }, function (statusCode) {
            file.errno = statusCode;
            _this.saveFile(i + 1, 0 /* useUpperCaseMd5 */);
        });
    };
    return RapiduploadTask;
}());
/* harmony default export */ const common_RapiduploadTask = (RapiduploadTask);

;// CONCATENATED MODULE: ./src/baidu/common/const.tsx




var host = location.host;
var rapid_url = "https://" + host + "/api/rapidupload";
var create_url = "https://" + host + "/rest/2.0/xpan/file?method=create";
var list_url = "https://" + host + "/rest/2.0/xpan/multimedia?method=listall&order=name&limit=10000";
// 已知api有限制: limit字段(即获取的文件数)不能大于10000, 否则直接返回错误
var meta_url = "https://" + host + "/rest/2.0/xpan/file?app_id=778750&method=meta&path=";
var meta_url2 = "https://" + host + "/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=";
var pcs_url = "https://pcs.baidu.com/rest/2.0/pcs/file?app_id=778750&method=download";
var UA = "netdisk;2.2.51.6;netdisk;10.0.63;PC;android-android;QTP/1.0.32.2"; // 自定义User-Agent
var illegalPathPattern = /[\\":*?<>|]/; // 匹配路径中的非法字符
var getBdstoken; // 获取bdstoken的实现
function setGetBdstoken(func) {
    getBdstoken = func;
}
var refreshList; // 刷新文件列表的实现
function setRefreshList(func) {
    refreshList = func;
}
var getSelectedFileList; // 获取选中的文件列表的实现
function setGetSelectedFileList(func) {
    getSelectedFileList = func;
}
var swalInstance = new swalBase(new common_RapiduploadTask(), new common_GeneratebdlinkTask());
var htmlTagNew = "div.nd-file-list-toolbar__actions"; // 新版界面秒传按钮的html父对象
var htmlTaglegacy = "div.tcuLAu"; // 旧版界面秒传按钮的html父对象
var htmlTag2legacy = "form.h5-uploader-form"; // 旧版界面秒传按钮的html同级对象
var htmlBtnRapidNew = // 新版界面秒传按钮的html元素
 '<button id="bdlink_btn" style="margin-left: 8px;" class="mzf_new_btn"></i><span>秒传</span></button>';
var htmlBtnGenNew = // 新版界面秒传生成按钮的html元素
 '<button id="gen_bdlink_btn" style="margin-left: 8px;" class="mzf_new_btn"></i><span>生成秒传</span></button>';
var htmlBtnRapidLegacy = // 旧版界面秒传按钮的html元素
 '<a class="g-button g-button-blue" id="bdlink_btn" title="秒传链接" style="display: inline-block;""><span class="g-button-right"><em class="icon icon-disk" title="秒传链接提取"></em><span class="text" style="width: auto;">秒传链接</span></span></a>';
var htmlBtnGenLegacy = // 旧版界面秒传生成按钮的html元素
 '<a class="g-button" id="gen_bdlink_btn"><span class="g-button-right"><em class="icon icon-share"></em><span class="text" style="width: auto;">生成秒传</span></span></a>';
function baiduErrno(errno) {
    switch (errno) {
        case -6:
            return "认证失败(尝试刷新页面/重新登录度盘账号)";
        case -7:
            return "秒传链接内的文件名/转存路径 包含非法字符, 请尝试更改";
        case -8:
            return "路径下存在同名文件";
        case 400:
            return "请求错误(尝试使用最新版Chrome浏览器/更新油猴插件)";
        case 403:
            return "\u63A5\u53E3\u9650\u5236\u8BBF\u95EE(\u8BF7\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + linkStyle + ">\u5206\u4EAB\u6559\u7A0B</a>)";
        case 31190:
        case 404:
            return "\u79D2\u4F20\u672A\u751F\u6548(\u8BF7\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + linkStyle + ">\u5206\u4EAB\u6559\u7A0B</a>)";
        case 2:
            return "转存失败(尝试重新登录度盘账号/更换或重装浏览器)";
        case 2333:
            return '秒传链接内的文件名错误, 不能含有字符\\":*?<>|, 且不能是"/"(空文件名)';
        case -10:
            return "网盘容量已满";
        case 514:
            return "请求失败(若弹出跨域提示,请选择允许/尝试关闭网络代理/更换浏览器)";
        case 1919:
            return "\u6587\u4EF6\u5DF2\u88AB\u548C\u8C10(\u8BF7\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + linkStyle + ">\u5206\u4EAB\u6559\u7A0B</a>)";
        case 996:
            return "md5\u83B7\u53D6\u5931\u8D25(\u8BF7\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + linkStyle + ">\u5206\u4EAB\u6559\u7A0B</a>)";
        case 500:
        case 502:
        case 503:
            return "\u670D\u52A1\u5668\u9519\u8BEF(\u8BF7\u53C2\u8003<a href=\"" + doc.shareDoc + "\" " + linkStyle + ">\u5206\u4EAB\u6559\u7A0B</a>)";
        case 909:
            return "路径不存在/文件已损坏";
        case 900:
            return "路径为文件夹, 不支持生成秒传";
        case 901:
            return "包含的文件数量超出限制(1w个)";
        default:
            return "未知错误";
    }
} // 自定义百度api返回errno的报错

;// CONCATENATED MODULE: ./src/baidu/newPage/loader.tsx



function installNew() {
    // 添加按钮并绑定事件 (新版页面目前还未实现秒传生成功能, 故只添加转存按钮)
    console.info("%s DOM方式安装，若失效请报告。", TAG);
    $(htmlTagNew).append(htmlBtnRapidNew, htmlBtnGenNew);
    $(document).on("click", "#bdlink_btn", function () {
        swalInstance.inputView();
    }); // 绑定转存秒传按钮事件
    $(document).on("click", "#gen_bdlink_btn", function () {
        swalInstance.generatebdlinkTask.reset();
        swalInstance.checkUnfinish();
    }); // 绑定生成秒传按钮事件
}

;// CONCATENATED MODULE: ./src/baidu/legacyPage/loader.tsx



function getSystemContext() {
    return unsafeWindow.require("system-core:context/context.js")
        .instanceForSystem;
}
function addGenBtn() {
    var listTools = getSystemContext().Broker.getButtonBroker("listTools");
    if (listTools && listTools.$box)
        $(listTools.$box).children("div").after(htmlBtnGenLegacy);
    else
        setTimeout(addGenBtn, 300);
}
function addBtn() {
    if ($(htmlTaglegacy).length)
        $(htmlTaglegacy).append(htmlBtnRapidLegacy);
    else
        setTimeout(addBtn, 100);
}
function installlegacy() {
    console.info("%s DOM方式安装，若失效请报告。", TAG);
    addBtn(); // DOM添加秒传按钮
    addGenBtn(); // DOM添加生成按钮
    $(document).on("click", "#bdlink_btn", function () {
        swalInstance.inputView();
    }); // 绑定秒传按钮事件
    $(document).on("click", "#gen_bdlink_btn", function () {
        swalInstance.generatebdlinkTask.reset();
        swalInstance.checkUnfinish();
    }); // 绑定生成按钮事件
}

;// CONCATENATED MODULE: ./src/baidu/loader.tsx






function loaderBaidu() {
    jQuery(function () {
        if (locUrl.indexOf(baiduNewPage) !== -1) {
            // 添加swal参数以防止新版界面下的body样式突变
            swalInstance.swalGlobalArgs = {
                heightAuto: false,
                scrollbarPadding: false,
            };
            setRefreshList(function () {
                document.querySelector(".nd-main-list").__vue__.reloadList();
            });
            setGetSelectedFileList(getSelectedFileListNew);
            setGetBdstoken(function () { return document.querySelector(".nd-main-list").__vue__.yunData.bdstoken; });
            installNew();
        } // 新版界面loader入口
        else {
            setRefreshList(function () {
                // 旧版界面, 调用原生方法刷新文件列表, 无需重新加载页面
                unsafeWindow
                    .require("system-core:system/baseService/message/message.js")
                    .trigger("system-refresh");
            });
            setGetSelectedFileList(getSelectedFileListLegacy);
            setGetBdstoken(function () { return unsafeWindow.locals.get("bdstoken"); });
            installlegacy();
        } // 旧版界面loader入口
        var bdlink = initQueryLink(); // 解析url中的秒传链接
        if (bdlink) {
            // 解析到秒传链接, 弹出转存窗口
            swalInstance.inputView(bdlink);
        }
        else if (!GM_getValue(updateInfoVer + "_no_first"))
            // 检查是否首次运行, 若是则弹出更新信息窗口
            swalInstance.updateInfo(function () {
                GM_setValue(updateInfoVer + "_no_first", true);
            });
        // 预先绑定好按钮事件
        $(document).on("click", "#kill_donate", function () {
            GM_setValue(feedbackVer + "_kill_donate", true);
            $("#mzf_donate").remove();
        }); // 赞助提示 "不再显示" 按钮
        $(document).on("click", "#kill_feedback", function () {
            GM_setValue(donateVer + "_kill_feedback", true);
            $("#mzf_feedback").remove();
        }); // 反馈提示 "不再显示" 按钮
        $(document).on("click", "#check_md5_btn", function () {
            swalInstance.checkMd5();
        }); // 测试秒传按钮
    });
} // 百度秒传脚本主函数入口

// EXTERNAL MODULE: ./src/components/checkBox.css
var checkBox = __webpack_require__(197);
var checkBox_default = /*#__PURE__*/__webpack_require__.n(checkBox);
// EXTERNAL MODULE: ./src/app.scss
var app = __webpack_require__(119);
var app_default = /*#__PURE__*/__webpack_require__.n(app);
;// CONCATENATED MODULE: ./src/common/injectStyle.tsx





/**
 * @description: 注入脚本样式
 */
function injectStyle() {
    GM_addStyle((app_default())); // 注入自定义样式
    GM_addStyle((checkBox_default())); // 注入checkBox选框样式
    var swalThemes = GM_getValue("swalThemes") || "Default"; // sweetAlert的主题(css), 默认为Default
    var defaultThemesCss = GM_getResourceText("swalCss") || GM_getResourceText("swalCssBak");
    if (swalThemes === "Default") {
        if (defaultThemesCss) {
            GM_addStyle(defaultThemesCss);
        }
        else {
            getThemesCss(swalThemes); // 暴力猴直接粘贴脚本代码可能不会将resource中的数据下载缓存，fallback到下载css代码
        }
        return;
    }
    var ThemesCss = GM_getValue("" + swalCssVer + swalThemes); // 下载非默认主题的css代码
    if (ThemesCss) {
        GM_addStyle(ThemesCss);
    }
    else {
        getThemesCss(swalThemes); // 未找到缓存, fallback到下载css代码
    }
    return;
}
/**
 * @description: 下载并注入对应主题的css样式代码, 会将css代码缓存本地
 * @param {string} swalThemes 主题包名
 */
function getThemesCss(swalThemes) {
    ajax({
        url: extCssUrl[swalThemes],
        method: "GET",
    }, function (data) {
        var ThemesCss = data.responseText;
        if (ThemesCss.length < 100) {
            showAlert(appError.SwalCssInvalid +
                ("\n\u9519\u8BEF\u6570\u636E:" + swalThemes + " InvalidCss:\n" + ThemesCss));
            return;
        } // 返回data数据长度过小, 判定为无效样式代码
        GM_setValue("" + swalCssVer + swalThemes, ThemesCss); // 缓存css代码
        GM_addStyle(ThemesCss); // 注入css
    }, function (statusCode) {
        showAlert(appError.SwalCssErrReq + ("#" + statusCode));
    });
}

;// CONCATENATED MODULE: ./src/app.tsx




/**
 * @description: 主函数入口
 */
function app_app() {
    // 检查外部依赖是否加载完整
    if ([typeof Base64, typeof $, typeof SparkMD5, typeof Swal].indexOf("undefined") !== -1)
        showAlert(appError.missDepend);
    // 缺少依赖, 弹窗提示
    else {
        Base64.extendString();
        injectStyle();
        loaderBaidu();
    }
}
// 广告拦截插件会导致脚本报错跳出, 网页卡死, 故加入异常处理
try {
    app_app();
}
catch (error) {
    console.log(error);
}

})();

/******/ })()
;